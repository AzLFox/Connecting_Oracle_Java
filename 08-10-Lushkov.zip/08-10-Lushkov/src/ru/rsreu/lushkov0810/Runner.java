package ru.rsreu.lushkov0810;

import ru.rsreu.lushkov0810.datalayer.DAOFactory;
import ru.rsreu.lushkov0810.datalayer.DBType;
import ru.rsreu.lushkov0810.data.*;
import ru.rsreu.lushkov0810.data.dto.*;
import ru.rsreu.lushkov0810.tools.*;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.List;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

public class Runner {
	
	private Runner() {
	}
	
	public static void main(String[] args) throws SQLException, ParseException {
		Resourcer resourser = ProjectResourcer.getInstance();
		DAOFactory factory = DAOFactory.getInstance(DBType.ORACLE);
		ElectiveDBDAO electiveDAO = factory.getDBElectiveDAO();
		
		Timestamp startDate = DateParser.getTimestampValue(resourser.getString("start.date"));
		Timestamp endDate = DateParser.getTimestampValue(resourser.getString("end.date"));
		List<StatementForPeriodDTO> statemenList = electiveDAO.getStatementForPeriod(startDate, endDate);
		TableConstructor.getTableStatementForPeriod(resourser.getString("first.table.head"), statemenList);
		
		List<Student> studentList = electiveDAO.getStudentListWhithElectiveGrade(resourser.getString("education.title"));
		TableConstructor.getTableStudentsWithAssessment(resourser.getString("second.table.head"), studentList);
		
		List<EducationResultDTO> educationResultList = electiveDAO.getElectiveAverageGrade();
		TableConstructor.getTableEducationResult(resourser.getString("third.table.head"), educationResultList);
	}

}

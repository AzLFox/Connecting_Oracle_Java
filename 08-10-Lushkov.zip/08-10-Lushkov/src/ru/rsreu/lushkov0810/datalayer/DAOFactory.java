package ru.rsreu.lushkov0810.datalayer;

import ru.rsreu.lushkov0810.datalayer.oracledb.OracleElectiveDBDAO;

public abstract class DAOFactory {
		public static DAOFactory getInstance(DBType dbType) {
			DAOFactory result = dbType.getDAOFactory();
			return result;
		}

		public abstract OracleElectiveDBDAO getDBElectiveDAO();
	}
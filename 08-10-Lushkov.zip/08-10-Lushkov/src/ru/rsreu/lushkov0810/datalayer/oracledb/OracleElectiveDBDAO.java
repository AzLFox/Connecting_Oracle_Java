package ru.rsreu.lushkov0810.datalayer.oracledb;

import java.sql.Connection;
import java.sql.Timestamp;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

import ru.rsreu.lushkov0810.data.*;
import ru.rsreu.lushkov0810.data.dto.*;

public class OracleElectiveDBDAO implements ElectiveDBDAO {
	private Connection connection;
	private Resourcer resourcer;

	public OracleElectiveDBDAO(Connection connection) {
		this.connection = connection;
		this.resourcer = ProjectResourcer.getInstance();
	}

	@Override
	public List<StatementForPeriodDTO> getStatementForPeriod(Timestamp startDate, Timestamp endDate)
			throws SQLException, ParseException {
		String query = resourcer.getString("first.query");
		List<StatementForPeriodDTO> statementList = new ArrayList<>();
		PreparedStatement preparedStatement = connection.prepareStatement(query);
		preparedStatement.setTimestamp(1, startDate);
		preparedStatement.setTimestamp(2, endDate);
		ResultSet resultSet = preparedStatement.executeQuery();

		while (resultSet.next()) {
			Student student = new Student(resultSet.getInt("student_code"), resultSet.getString("surname"),
					resultSet.getString("name"), resultSet.getString("patronymic"), resultSet.getLong("telephone"));
			Elective elective = new Elective(resultSet.getInt("elective_code"), resultSet.getString("title"),
					resultSet.getDate("beginning_date"), resultSet.getInt("volume_lectures"),
					resultSet.getInt("volume_practices"), resultSet.getInt("volume_labwork"));
			StatementForPeriodDTO statement = new StatementForPeriodDTO(student, elective,
					resultSet.getInt("ASSESSMENT"));
			statementList.add(statement);
		}
		return statementList;
	}

	public List<Student> getStudentListWhithElectiveGrade(String elective) throws SQLException, ParseException {
		String query = resourcer.getString("second.query");
		List<Student> studentList = new ArrayList<>();
		PreparedStatement preparedStatement = connection.prepareStatement(query);
		preparedStatement.setString(1, elective);
		ResultSet resultSet = preparedStatement.executeQuery();

		while (resultSet.next()) {
			Student student = new Student(resultSet.getInt("student_code"), resultSet.getString("surname"),
					resultSet.getString("name"), resultSet.getString("patronymic"), resultSet.getLong("telephone"));
			studentList.add(student);
		}
		return studentList;
	}

	public List<EducationResultDTO> getElectiveAverageGrade() throws SQLException, ParseException {
		String query = resourcer.getString("third.query");
		List<EducationResultDTO> educationResultList = new ArrayList<>();
		PreparedStatement preparedStatement = connection.prepareStatement(query);
		ResultSet resultSet = preparedStatement.executeQuery();

		while (resultSet.next()) {
			EducationResultDTO resultDTO = new EducationResultDTO(resultSet.getString("title"),
					resultSet.getDouble("average_assessment"));
			educationResultList.add(resultDTO);
		}
		return educationResultList;
	}
}

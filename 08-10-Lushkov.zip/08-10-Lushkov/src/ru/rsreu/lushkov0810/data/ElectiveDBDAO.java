package ru.rsreu.lushkov0810.data;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.List;

import ru.rsreu.lushkov0810.data.dto.*;

public interface ElectiveDBDAO {
	List<StatementForPeriodDTO> getStatementForPeriod(Timestamp startDate, Timestamp endDate) throws SQLException, ParseException;
	List<Student> getStudentListWhithElectiveGrade(String elective) throws SQLException, ParseException;
	List<EducationResultDTO> getElectiveAverageGrade() throws SQLException, ParseException;
}

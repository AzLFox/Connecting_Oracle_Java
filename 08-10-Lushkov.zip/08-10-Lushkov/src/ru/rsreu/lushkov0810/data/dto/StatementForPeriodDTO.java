package ru.rsreu.lushkov0810.data.dto;

import ru.rsreu.lushkov0810.data.*;

public class StatementForPeriodDTO {
	private String surname;
	private String name;
	private String patronynmic;
	private String title;
	private int assessment;
	
	public StatementForPeriodDTO(Student student, Elective elective, int assessment) {
		this.surname = student.getSurname();
		this.name = student.getName();
		this.patronynmic = student.getPatronymic();
		this.title = elective.getTitle();
		this.assessment = assessment;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPatronynmic() {
		return patronynmic;
	}

	public void setPatronynmic(String patronynmic) {
		this.patronynmic = patronynmic;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getAssessment() {
		return assessment;
	}

	public void setAssessment(int assessment) {
		this.assessment = assessment;
	}
	
	
}

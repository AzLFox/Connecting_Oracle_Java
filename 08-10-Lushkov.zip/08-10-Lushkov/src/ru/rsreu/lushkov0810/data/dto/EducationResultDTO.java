package ru.rsreu.lushkov0810.data.dto;

public class EducationResultDTO {
	
	private String title;
	private double avgAssessment;
	
	public EducationResultDTO(String title, double avgAssessment) {
		this.title = title;
		this.avgAssessment = avgAssessment;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public double getAvgAssessment() {
		return avgAssessment;
	}

	public void setAvgAssessment(double avgAssessment) {
		this.avgAssessment = avgAssessment;
	}
	
	
}

package ru.rsreu.lushkov0810.data;

public class EducationResult {
	private int studentCode;
	private int electiveCode;
	private int assessment;
	
	public EducationResult(int studentCode, int electiveCode, int assessment) {
		this.studentCode = studentCode;
		this.electiveCode = electiveCode;
		this.assessment = assessment;
	}

	public int getStudentCode() {
		return studentCode;
	}

	public void setStudentCode(int studentCode) {
		this.studentCode = studentCode;
	}

	public int getElectiveCode() {
		return electiveCode;
	}

	public void setElectiveCode(int electiveCode) {
		this.electiveCode = electiveCode;
	}

	public int getAssessment() {
		return assessment;
	}

	public void setAssessment(int assessment) {
		this.assessment = assessment;
	}
	
	
}

package ru.rsreu.lushkov0810.data;

import java.sql.Date;

public class Elective {
	private int electiveCode;
	private String title;
	private Date beginningDate;
	private int volumeLectures;
	private int volumePractices;
	private int volumeLabworks;
	
	public Elective(int electiveCode, String title, Date beginningDate, int volumeLectures, int volumePractices, int volumeLabworks) {
		this.electiveCode = electiveCode;
		this.title = title;
		this.beginningDate = beginningDate;
		this.volumeLectures = volumeLectures;
		this.volumePractices = volumePractices;
		this.volumeLabworks = volumeLabworks;
	}

	public int getElectiveCode() {
		return electiveCode;
	}

	public void setElectiveCode(int electiveCode) {
		this.electiveCode = electiveCode;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getBeginningDate() {
		return beginningDate;
	}

	public void setBeginningDate(Date beginningDate) {
		this.beginningDate = beginningDate;
	}

	public int getVolumeLectures() {
		return volumeLectures;
	}

	public void setVolumeLectures(int volumeLectures) {
		this.volumeLectures = volumeLectures;
	}

	public int getVolumePractices() {
		return volumePractices;
	}

	public void setVolumePractices(int volumePractices) {
		this.volumePractices = volumePractices;
	}

	public int getVolumeLabworks() {
		return volumeLabworks;
	}

	public void setVolumeLabworks(int volumeLabworks) {
		this.volumeLabworks = volumeLabworks;
	}
	
	
}

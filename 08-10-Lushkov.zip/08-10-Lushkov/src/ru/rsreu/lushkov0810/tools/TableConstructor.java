package ru.rsreu.lushkov0810.tools;

import java.util.List;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

import ru.rsreu.lushkov0810.data.Student;
import ru.rsreu.lushkov0810.data.dto.EducationResultDTO;
import ru.rsreu.lushkov0810.data.dto.StatementForPeriodDTO;

public class TableConstructor {
	private static Resourcer resourser = ProjectResourcer.getInstance();

	private TableConstructor() {
	}

	public static void getTableStatementForPeriod(String head, List<StatementForPeriodDTO> statemenList) {

		System.out.printf(head);

		System.out.println(resourser.getString("first.table.start.line"));
		System.out.printf(resourser.getString("first.table.format"), resourser.getString("first.table.surname"),
				resourser.getString("first.table.name"), resourser.getString("first.table.patronynmic"),
				resourser.getString("first.table.title"), resourser.getString("first.table.assessment"));
		System.out.println(resourser.getString("first.table.between.line"));
		for (StatementForPeriodDTO statement : statemenList) {
			System.out.printf(resourser.getString("first.table.format"), statement.getSurname(), statement.getName(),
					statement.getPatronynmic(), statement.getTitle(), statement.getAssessment());
		}
		System.out.println(resourser.getString("first.table.end.line"));
	}

	public static void getTableStudentsWithAssessment(String head, List<Student> studentList) {

		System.out.printf(head);

		System.out.println(resourser.getString("second.table.start.line"));
		System.out.printf(resourser.getString("second.table.format"), resourser.getString("first.table.surname"),
				resourser.getString("first.table.name"), resourser.getString("first.table.patronynmic"),
				resourser.getString("first.table.title"), resourser.getString("first.table.assessment"));
		System.out.println(resourser.getString("second.table.between.line"));
		for (Student student : studentList) {
			System.out.printf(resourser.getString("second.table.format"), student.getSurname(), student.getName(),
					student.getPatronymic());
		}
		System.out.println(resourser.getString("second.table.end.line"));
	}

	public static void getTableEducationResult(String head, List<EducationResultDTO> educationResultList) {

		System.out.printf(head);

		System.out.println(resourser.getString("third.table.start.line"));
		System.out.printf(resourser.getString("third.table.format.string"), resourser.getString("third.table.title"),
				resourser.getString("third.table.avg"));
		System.out.println(resourser.getString("third.table.between.line"));
		for (EducationResultDTO educationResult : educationResultList) {
			System.out.printf(resourser.getString("third.table.format"), educationResult.getTitle(),
					educationResult.getAvgAssessment());
		}
		System.out.println(resourser.getString("third.table.end.line"));
	}
}

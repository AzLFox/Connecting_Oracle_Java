package ru.rsreu.lushkov0810.tools;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateParser {

	private DateParser() {
	}

	public static Timestamp getTimestampValue(String date) throws ParseException {
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date dDate = null;
		dDate = format.parse(date);
		return new Timestamp(dDate.getTime());
	}
}
